#!/bin/bash
# Script de compilation rapide
echo "Compilation du loader OPSEC..."
gcc -o opsec_loader opsec_loader.cpp -lcrypto -lpthread
if [ $? -eq 0 ]; then
    echo "Compilation réussie!"
    echo "Exécutez avec: ./opsec_loader encrypted.bin vnxkRb+e64ygdG+k"
else
    echo "Erreur de compilation. Assurez-vous que les bibliothèques requises sont installées."
    echo "Sur Ubuntu/Debian: sudo apt-get install libssl-dev"
fi
